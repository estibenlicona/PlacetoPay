<?php
//Credenciales Base de Datos
define('HOST_NAME', 'localhost');
define('DATABASE_NAME', 'bd_placetopay');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8');

//Credenciales PlaytoPace
define('URL', 'https://test.placetopay.com/redirection/api/session');
define('LOGIN', '6dd490faf9cb87a9862245da41170ff2');
define('SECRECTKEY', '024h1IlD');
?>